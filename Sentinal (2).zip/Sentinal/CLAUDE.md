# Project Sentinel — Cursor Orchestration Controller

**Last updated:** July 23, 2026 (workflow hardening)

If this file conflicts with `Review_Guidelines.mdc`, follow `Review_Guidelines.mdc`. Legacy compatibility rules never override current Sentinel Ultra policy.

This file routes work and describes execution safety. It does **not** redefine authoritative Sentinel policy.

| Document | Authority |
|----------|-----------|
| `document 1.txt` / `document 2.txt` / `document 3.txt` | Official Ultra docs (July 22, 2026) |
| `.cursor/rules/Review_Guidelines.mdc` | Authoritative **policy** (`alwaysApply: true` only) |
| `.cursor/rules/Sentinel_Submitter_Platform_Workflow.mdc` | Submitter procedure / branches |
| `.cursor/rules/Sentinel_Expert_Contributor_Reference.mdc` | Short quick reference |
| `.cursor/rules/Sentinel_Reviewer_Step_by_Step.mdc` | Reviewer procedure |
| `CLAUDE.md` (this file) | Discovery, routing, execution safety, outputs |
| `AGENTS.md` | Concise entry point |
| `automation/sentinel_submitter.py` | Gates and packaging only (no auto-verdicts) |

Never confuse submitter and reviewer roles, verdicts, or templates.

---

## Rule Precedence

1. Official Ultra docs + **live platform fields**
2. Current user instruction (only when it does not conflict with authoritative requirements)
3. `Review_Guidelines.mdc`
4. Role workflow (submitter or reviewer `.mdc`)
5. Expert quick reference
6. Labelled legacy compatibility only

Only `Review_Guidelines.mdc` may use `alwaysApply: true`. Backup/legacy `.mdc` files under `legacy_backup/` are not active Cursor rules.

---

## Operating Modes

Do not pick a mode from an isolated keyword (Accept, Reject, Fixable, Invalid). Use explicit role, requested action, platform section, files, and context.

### Submitter Mode

Activate on equivalents of:

- I am working as a submitter. Start working.
- Process this Sentinel submission.
- Prepare this task for submission.
- Audit this task and follow the correct submitter branch.
- Analyze this task and give me all submitter answers.
- Review and correct this Sentinel submission.

When clear, do not ask for a long workflow prompt. Follow `Sentinel_Submitter_Platform_Workflow.mdc`.

Submitter summary:

1. Intake ZIP + platform information
2. Preserve original ZIP
3. Audit original task
4. Determine Public Main Analysis
5. Determine Internal Validity separately (with reason)
6. Make Duplicate Analysis match Public Main Analysis
7. Select branch using Duplicate Analysis
8. Fix only in `working_copy/` when Duplicate is Fixable
9. Evidence package when Duplicate is Invalid/Not Fixable
10. No task changes when Duplicate is Valid-as-is
11. Answer all platform fields in chat
12. Generate branch-specific `task_outputs/`

Block final answer generation when Public and Duplicate disagree. Do not infer Internal from Duplicate. Do not infer verdicts from folder names, command names, or previous tasks.

### Reviewer Mode

Activate on equivalents of:

- I am working as a reviewer. Start working.
- Review this submission.
- Verify the submitter’s work.
- Perform an independent Sentinel review.

Reviewer Mode is read-only for the submitted package. No corrected ZIP. Optional targeted checks only in disposable copies. Output `review_answer.txt`.

### Rule Maintenance / Read-Only Audit

Rule maintenance updates these Sentinel files only. Read-only audit analyzes without modification.

If mode is genuinely ambiguous and affects allowed edits, ask once:

```text
Are you acting as the submitter or reviewer for this task?
```

If the mode is clear, do not ask again.

---

## Workspace Discovery and Safety

Ignore: `legacy_backup/`, `workspace_archive/`, `completed_tasks/`, previous `task_outputs/`, `.cursor/`, automation caches.

Never auto-select tasks from archives, backups, old outputs, or old corrected ZIPs.

Layout:

```text
incoming_tasks/
work/<task>/original|extracted_original|working_copy|session|analysis/
task_outputs/<task>/workflow_state.json|platform_answers.txt|reports|updated_zip_file/|invalid_evidence/
completed_tasks/
automation/sentinel_submitter.py
```

Mutations only on `working_copy/` (Fixable submitter). Never mutate `extracted_original/`. Never overwrite the original ZIP. Corrected ZIP only after Fixable preflight (`ready_to_package`).

Multiple credible task roots: stop and require explicit `select-task`. Never choose by mtime or alphabet.

---

## Fail-to-Pass (Operational Routing)

- <10 meaningful f2p → Fixable issue; may add tests via `tests.patch` in working_copy
- Exactly 10 meets documented minimum
- Live “more than 10” confirmation → ≥11 only
- Never filler tests; never edit existing p2p/regression tests
- Count ≠ semantic proof

---

## Three Fields / Nine Cases

Public ∈ {Fixable, Invalid/Not Fixable, Valid as-is}  
Internal ∈ {Invalid, Fixable, Valid-as-is}  
Duplicate ∈ {Fixable, Invalid/Not Fixable, Valid-as-is}

Duplicate controls branch. All nine Internal×Duplicate combinations supported. Record Internal reason in `workflow_state.json`.

---

## Validation Claims

Distinguish Inspected / Inferred / Executed / Confirmed by supplied logs / Not verified. Never invent validation results, issue evidence, test counts, or handling times. Use `User confirmation required` when times are unreliable.

Valid-as-is: local Docker + Oracle 1.0 + NOP 0.0 required when technically available.  
Fixable: local strongly recommended; failed local check blocks ready packaging claim; `not_run` → `locally_prepared_platform_evaluation_required`.  
Reviewer: local optional.

---

## Outputs

Chat must include the full SENTINEL SUBMITTER PLATFORM ANSWERS block. Also write `task_outputs/<task>/platform_answers.txt` plus audit/findings/validation reports. Do not place reports inside the upload ZIP.

---

## Automation Commands

```text
intake → prepare → audit → set-verdicts → (Fixable edits) → record-validation → preflight → package-* → status → archive
```

Script never decides verdicts.

---

## Active Rules Explicitly Removed

- Permanently read-only Submitter Mode for all branches
- Auto-modifying every task
- Auto-select task root by mtime/alphabet when multiple exist
- Packaging without preflight
- Claiming validation from verdict alone
- Invented handling times
