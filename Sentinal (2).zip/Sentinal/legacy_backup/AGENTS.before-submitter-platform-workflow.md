# Project Sentinel Instructions

Follow the Project Sentinel orchestration and operating-mode rules in `CLAUDE.md`.

`CLAUDE.md` must explicitly load the relevant role-specific rule files before work begins (see **Mandatory Role-Specific Rule Loading** in `CLAUDE.md`).

Use these Cursor rules:

- `.cursor/rules/Review_Guidelines.mdc` for authoritative Sentinel policy
- `.cursor/rules/Sentinel_Expert_Contributor_Reference.mdc` for quick-reference checklists
- `.cursor/rules/Sentinel_Reviewer_Step_by_Step.mdc` for reviewer-specific procedure

The official Sentinel Ultra documents dated July 22, 2026 (`document 1.txt`, `document 2.txt`, `document 3.txt`) override conflicting legacy rules.

Never mix submitter and reviewer verdicts, workflows or output templates.
