# Sentinel Submitter Automation

Cursor-assisted Sentinel workflow safety gates and packaging helpers.

**This repository is a Cursor-assisted Sentinel workflow. It provides safety gates and structured checks, but expert review remains required.**

If guidance here conflicts with `Review_Guidelines.mdc`, follow `Review_Guidelines.mdc`. Legacy rules never override current Sentinel Ultra policy.

The script **never decides verdicts** and never modifies task logic by itself.

## Simple workflow

```bash
python automation/sentinel_submitter.py intake --zip <task.zip>
python automation/sentinel_submitter.py prepare
python automation/sentinel_submitter.py audit
python automation/sentinel_submitter.py set-verdicts \
  --public-analysis Fixable \
  --internal-validity Fixable \
  --duplicate-analysis Fixable \
  --reason "evidence-based reason"
# Cursor applies reviewed Fixable corrections to working_copy only
python automation/sentinel_submitter.py sync-problem-statement
python automation/sentinel_submitter.py record-validation --check docker_build --status passed --evidence path/to/log
python automation/sentinel_submitter.py record-validation --check oracle --status passed --evidence path/to/log --reward 1.0
python automation/sentinel_submitter.py record-validation --check nop --status passed --evidence path/to/log --reward 0.0
python automation/sentinel_submitter.py preflight
python automation/sentinel_submitter.py package-fixable
python automation/sentinel_submitter.py status
```

Other commands: `select-task <path>`, `package-invalid`, `archive`.

## Key rules

- Original ZIP remains unchanged.
- Internal Validity is independent; Duplicate Analysis controls the branch.
- Public and Duplicate answers must match.
- Valid-as-is creates no new task ZIP.
- Fixable packaging requires preflight (`ready_to_package`).
- Invalid produces evidence only (manual-review package).
- Structural checks do not prove semantic correctness.
- Expert review remains required.
- Validation claims must be evidence-based.
- Multiple task roots require explicit `select-task`.
- No real task should be used for automation configuration tests.

## Outputs

`task_outputs/<task>/workflow_state.json` plus reports, corrected ZIP, or invalid evidence ZIP.
