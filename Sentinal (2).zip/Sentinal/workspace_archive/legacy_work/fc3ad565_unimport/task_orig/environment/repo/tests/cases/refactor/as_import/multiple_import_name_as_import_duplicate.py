import bar

print(bar)
