## Bug: project config is ignored at runtime

`unimport` reads settings from `pyproject.toml` (`[tool.unimport]`) and `setup.cfg` (`[unimport]`), but those values never actually win when the tool runs. A user who sets something like `exclude` / `remove` in a config file and then runs with `--config` still sees default CLI behavior (for example unused imports are not removed, and configured exclude paths are still scanned). The file is parsed, but the effective configuration still looks like the CLI defaults.

Please rework the configuration layer so file-based settings are honored without breaking the existing CLI surface.

## What should change

Split configuration into a value object and a file/CLI parser:

- Export `Config` and `ParseConfig` from `unimport.config` (remove the old `DefaultConfig` type). Keep a recognized config-file → section mapping available (`setup.cfg` → `unimport`, `pyproject.toml` → `tool.unimport`).
- `Config` holds the effective settings with the existing defaults: sources defaulting to `[Path(".")]` (also as `Config.default_sources`), `include` / `exclude` from the existing constants, and booleans for `requirements`, `gitignore`, `remove`, `diff`, `include_star_import`, `permission`, `check`, and `ignore_init`, plus `color="auto"`.
- After construction, derive:
  - `diff` true when `diff` or `permission` was requested
  - `check` true when explicitly requested, or when neither `diff` nor `remove` is active (so a bare default config is check-mode)
  - `use_color` from the `color` setting
- When `gitignore` and/or `ignore_init` are enabled, append the corresponding exclude patterns to `exclude`; otherwise leave `exclude` alone.
- `Config.build(args=..., config_context=...)` merges CLI values with a parsed file mapping. A CLI value should override the file only when it is present and differs from that field’s default; otherwise prefer the file value, then the field default. Calling `build` with neither argument yields defaults.
- `ParseConfig(config_file=...).parse()` returns a plain `dict` of only the keys present in that file’s unimport section (not a defaults-filled object). Missing section → `{}`. Convert `sources` entries to `Path`, keep booleans/strings typed.
- `ParseConfig.parse_args(args)` is what `main` should call instead of the old config entrypoint: if `--config` names a recognized config file, parse it and `Config.build` with both the argparse namespace and that context; otherwise build from the CLI args alone. A recognized config path whose unimport section is absent must behave like a plain default `Config.build()`. Downstream colorized output should use `config.use_color`, not the raw `--color` string.
- Move color enablement onto `Config` (including a `Config._use_color(color)` helper). Accepted values are `auto` / `always` / `never`; anything else raises `ValueError` whose message includes the bad value. `auto` follows terminal color support and whether stderr is a tty. Remove the old standalone `use_color` helper and `add_color_option` from `unimport.color`; keep exporting `RED`, `RESET`, `TERMINAL_SUPPORT_COLOR`, and `paint`. `paint` still takes a third flag, now named `use_color`.
- CLI `--color` must remain a string through argparse (not coerced to bool). Command helpers that previously took `use_color_setting` should take `use_color` with the same behavior. Other flags continue to map onto the same-named `Config` fields.

## Constraints

- Do not edit the evaluation tests or fixtures; the harness injects them.
- Aside from the removals above, keep `unimport.color`’s remaining public behavior intact.
- Boolean conversion of `--color` happens only when computing `use_color` on `Config`.
