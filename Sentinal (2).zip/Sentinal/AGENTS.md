# Project Sentinel Instructions

Follow `CLAUDE.md` for mode routing. If this file conflicts with `Review_Guidelines.mdc`, follow `Review_Guidelines.mdc`. Legacy compatibility rules never override current Sentinel Ultra policy.

## Rules

- `.cursor/rules/Review_Guidelines.mdc` — authoritative policy (`alwaysApply: true` only)
- `.cursor/rules/Sentinel_Submitter_Platform_Workflow.mdc` — submitter procedure
- `.cursor/rules/Sentinel_Expert_Contributor_Reference.mdc` — short checklists
- `.cursor/rules/Sentinel_Reviewer_Step_by_Step.mdc` — reviewer procedure
- `automation/sentinel_submitter.py` — safety gates / packaging (never auto-verdicts)

## Submitter Mode

Examples: `I am working as a submitter. Start working.` · `Process this Sentinel submission.` · `Prepare this task for submission.` · `Audit this task and follow the correct submitter branch.`

1. Intake ZIP; preserve original
2. Prepare / audit original
3. Set Public Main Analysis; set Internal Validity separately with reason; set Duplicate to match Public
4. Branch on Duplicate only
5. Fixable → edit `working_copy/` only → record-validation → preflight → package-fixable
6. Invalid → evidence package only
7. Valid-as-is → confirm; no new ZIP
8. Return all answers in chat + `task_outputs/`

## Reviewer Mode

Examples: `I am working as a reviewer. Start working.` · `Review this submission.` · `Verify the submitter’s work.` · `Perform an independent Sentinel review.`

Read-only. No task edits. No corrected ZIP. Write `review_answer.txt`.

Do not mix submitter and reviewer verdicts. Official Ultra docs (July 22, 2026) override legacy rules.
